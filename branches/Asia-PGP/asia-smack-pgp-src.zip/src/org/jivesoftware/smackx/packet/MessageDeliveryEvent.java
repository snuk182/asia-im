package org.jivesoftware.smackx.packet;

public class MessageDeliveryEvent extends MessageEvent {
	
	@Override
	public String getElementName() {
        return "request";
    }
	
	@Override
	public String getNamespace() {
        return "urn:xmpp:receipts";
    }
	
	@Override
	public String toXML() {
        StringBuilder buf = new StringBuilder();
        buf.append("<").append(getElementName()).append(" xmlns=\"").append(getNamespace()).append(
            "\" />");
        return buf.toString();
    }
}
