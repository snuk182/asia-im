package org.jivesoftware.smackx.provider;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.jivesoftware.smackx.packet.MessageEvent;
import org.xmlpull.v1.XmlPullParser;

public class MessageDeliveryProvider implements PacketExtensionProvider{
	
	public MessageDeliveryProvider() {
    }

	@Override
	public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
		MessageEvent messageEvent = new MessageEvent();
        boolean done = false;
        while (!done) {
            int eventType = parser.next();
            if (eventType == XmlPullParser.START_TAG) {
                if (parser.getName().equals("id"))
                    messageEvent.setPacketID(parser.nextText());
                messageEvent.setDelivered(true);
            } else if (eventType == XmlPullParser.END_TAG) {
                if (parser.getName().equals("received")) {
                    done = true;
                }
            }
        }

        return messageEvent;
	}

}
